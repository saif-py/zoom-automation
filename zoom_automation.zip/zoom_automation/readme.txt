welcome to the zoom automation software made by Mohd Saif Siddiqui
just enter your meeting id password and time(24hr format)
and it willl automatically join the meeting at the right time
note:-it may take some time even after the meeting time has reached due to its algorithm to stop it's until the right time 
	so don't worry just give it around half a second and your work will be done
to get started launch the start.exe and you'll see what to do 
you need to first click on the save info button and then done after saving all your future meetings of the day 



for any further details and enquiries contact at mohdsaifsiddiqui10@gmail.com
or https://github.com/saif-py/zoom-automation 
